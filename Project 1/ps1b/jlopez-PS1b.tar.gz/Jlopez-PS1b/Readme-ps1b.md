# PS0: Hello SFML
## reason for such late turn in
Dear professor sorry for turning this in so late. Fell behind because of ps1a and had technical issues setting up a home machine so I could work outside the school computer labs. My time in lab was limited by my full time job.

## Contact
Name: Juan Lopez 
Section: 011
Time to Complete: 1 day


## Description
Program takes image file and reassigns pixel new color value with the seed given using our previous LFSR code

### Features
Found an SFML feature to create three variables to hold color value that could extract the color. I then used the nested for loop that made the picture negative to make it change their color values.

### Issues
I cannot get the orgiinal image to display along side the decrypted/encrypted. Will go back and fix it soon, I would just like to get to the next project before I fall further behind.

### Extra Credit
Anything special you did.  This is required to earn bonus points.


## Acknowledgements
SFML Library website
IT department that helped me get my linux laptop working
