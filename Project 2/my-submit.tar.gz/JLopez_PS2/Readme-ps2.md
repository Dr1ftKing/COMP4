# PS2: Triangle

## Contact
Name: Juan
Section: 011
Time to Complete: too long


## Description
Program calls recursive function creating triangles based off the the side length given and the depth of the trianles input. 

### Features
I first had the program create a convex sape with three verticies and from their I was able to make a triangle by setting variables for each side of the triangle. My main program then takes the triangle created with our inputs and pushes it into a vector. once in the vector my free function will iterate through creating more triagnels below, left and to the right according to the input. Within the function I got my triangle to be multiple colors by creating a random color generator anywhere a color is being set.

### Issues
makefile lint issues

### Extra Credit
My triangles are diffrent colors.


## Acknowledgements
SFML dev forums.



cpplint --filter=-runtime/references,-build/header_guard,-build/c++11 --extensions=cpp,hpp